using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletController : MonoBehaviour
{
    private Rigidbody2D myRigidbody2D;
    public GameManager myGameManager;
    public float bulletSpeed = 10f;

    // Start is called before the first frame update
    void Start()
    {
        myRigidbody2D = GetComponent<Rigidbody2D>();
        myGameManager = FindObjectOfType<GameManager>();
    }

    // Update is called once per frame
    void Update()
    {
        myRigidbody2D.velocity = new Vector2(bulletSpeed, myRigidbody2D.velocity.y);
    }

    void OnTriggerEnter2D(Collider2D collision){
        if(collision.CompareTag("ItemGood")){
            Destroy(collision.gameObject);
        } else if(collision.CompareTag("ItemBad")){
            Destroy(collision.gameObject);
            myGameManager.AddScore();
        }
    }
}
