using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    public float Speed;
    public float JumpForce;

    private float Horizontal;
    private Rigidbody2D Rigidbody2D;

    public Animator animator;
    private SpriteRenderer spriteRenderer;
    public GameManager myGameManager;
    public GameObject Bullet;

    // Start is called before the first frame update
    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        Rigidbody2D = GetComponent<Rigidbody2D>();
        myGameManager = FindObjectOfType<GameManager>();
    }

    // Update is called once per frame
    void Update()
    {
        Horizontal = Input.GetAxisRaw("Horizontal");
        
        if(Input.GetKeyDown(KeyCode.Space)){
            Jump();
        }

        if(Input.GetKeyDown(KeyCode.E)){
            Instantiate(Bullet, transform.position, Quaternion.identity);
        }
        
        if(Input.GetKey("d") || Input.GetKey("right")){
            Rigidbody2D.velocity= new Vector2(Speed, Rigidbody2D.velocity.y);
            spriteRenderer.flipX = false;
            animator.SetBool("Run",true);
        }
        else if(Input.GetKey("a") || Input.GetKey("left")){
            Rigidbody2D.velocity = new Vector2(-Speed, Rigidbody2D.velocity.y);
            spriteRenderer.flipX = true;
            animator.SetBool("Run",true);
        }  
        else{
            Rigidbody2D.velocity = new Vector2(0, Rigidbody2D.velocity.y);
            animator.SetBool("Run",false);
        }   
    }

    private void FixedUpdate(){
        Rigidbody2D.velocity = new Vector2(Horizontal*Speed, Rigidbody2D.velocity.y);
    }

    private void Jump(){
        Rigidbody2D.velocity = new Vector2(Rigidbody2D.velocity.x, JumpForce);
    }

    void OnTriggerEnter2D(Collider2D collision){
        if(collision.CompareTag("ItemGood")){
            Destroy(collision.gameObject);
            myGameManager.AddScore();
        } else if(collision.CompareTag("ItemBad")){
            Destroy(collision.gameObject);
            PlayerDeath();
        } else if(collision.CompareTag("DeathZone")){
            PlayerDeath();
        }
    }

    void PlayerDeath(){
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}